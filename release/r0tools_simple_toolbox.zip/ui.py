import logging

import bpy

from . import ext_update as upd
from . import utils as u
from .data_ops.data_operators import SimpleToolbox_OT_ClearCustomSplitNormalsData
from .data_ops.ui import (
    draw_clear_custom_properties_ui,
    draw_clear_objects_attributes_ui,
)
from .defines import (
    ADDON_BRANCH,
    ADDON_CATEGORY,
    ADDON_NAME_BARE,
    IDNAME_EXTRA,
    VERSION_STR,
)
from .find_modifiers_ops import SimpleToolbox_OT_FindModifiersCategoryVisCollapse
from .operators import *
from .repo import draw_repo_layout

log = logging.getLogger(__name__)


class r0Tools_PT_SimpleToolbox(bpy.types.Panel):
    bl_idname = "OBJECT_PT_simple_toolbox"
    bl_label = f"{ADDON_NAME_BARE}{IDNAME_EXTRA} ({VERSION_STR})"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = ADDON_CATEGORY
    # bl_options = {"DEFAULT_CLOSED"}
    bl_order = 0
    has_update = False

    @classmethod
    def _update_callback(cls, result):
        cls.has_update = result

        # Trigger redraw
        try:
            for area in bpy.context.screen.areas:
                if area.type == cls.bl_space_type:
                    area.tag_redraw()
        except Exception as e:
            log.error(f"Failed to redraw on callback:\n{e}")

    def draw(self, context):
        addon_props = u.get_addon_props()
        addon_prefs = u.get_addon_prefs()
        addon_find_modifier_props = u.get_addon_find_modifier_props()

        layout = self.layout

        row = layout.row()
        categories_column = row.column()
        special_categories_column = row.column()
        special_categories_row = special_categories_column.row()

        categories_entries = categories_column.grid_flow(
            row_major=True, columns=6, even_columns=False, even_rows=False, align=True
        )
        categories_entries.prop(addon_props, "cat_show_object_ops", text="", icon="EVENT_O")
        categories_entries.prop(addon_props, "cat_show_mesh_ops", text="", icon="EVENT_M")
        categories_entries.prop(addon_props, "cat_show_uv_ops", text="", icon="EVENT_U")
        categories_entries.prop(addon_props, "cat_show_custom_properties_editor", text="", icon="EVENT_C")
        categories_entries.prop(addon_props, "cat_show_find_modifiers_ops", text="", icon="MODIFIER")
        categories_entries.prop(addon_props, "cat_show_object_sets_editor", text="", icon="MESH_CUBE")
        categories_entries.prop(addon_props, "cat_show_vertex_groups_editor", text="", icon="GROUP_VERTEX")
        categories_entries.prop(addon_props, "cat_show_edge_data_panel", text="", icon="EDGESEL")
        if addon_prefs.experimental_features:
            categories_entries.prop(addon_props, "cat_show_quick_export_panel", text="", icon="EXPORT")

        # Right control region
        special_categories_row.prop(addon_prefs, "dev_tools", text="", icon="TOOL_SETTINGS")
        special_categories_row.prop(addon_prefs, "experimental_features", text="", icon="EXPERIMENTAL")

        # Category visibility properties
        cat_show_object_ops = addon_props.cat_show_object_ops
        cat_show_mesh_ops = addon_props.cat_show_mesh_ops
        cat_show_uv_ops = addon_props.cat_show_uv_ops
        cat_show_find_modifiers_ops = addon_props.cat_show_find_modifiers_ops
        cat_show_custom_properties_editor = addon_props.cat_show_custom_properties_editor

        # Category panel visibility properties
        panelvis_dev_tools = "panelvis_dev_tools"
        panelvis_object_ops = "panelvis_object_ops"
        panelvis_mesh_ops = "panelvis_mesh_ops"
        panelvis_uv_ops = "panelvis_uv_ops"
        panelvis_find_modifier_ops = "panelvis_find_modifier_ops"
        panelvis_custom_properties_ops = "panelvis_custom_properties_ops"
        panelvis_object_modifiers_ops = "panelvis_object_modifiers_ops"

        is_dev_branch = ADDON_BRANCH.lower().startswith("dev")

        if self.has_update:
            from .repo import SimpleToolbox_OT_TakeMeToUpdate

            update_box = layout.box()
            update_row = update_box.row(align=True)
            update_row.label(text="", icon="FUND")
            update_row.label(text="UPDATE AVAILABLE", icon="FILE_REFRESH")
            update_row.label(text="", icon="FUND")

            # Open Extensions tab in Preferences
            update_row = update_box.row(align=True)
            op = update_row.operator(
                SimpleToolbox_OT_TakeMeToUpdate.bl_idname, text="Take me to Extensions!", icon="INDIRECT_ONLY_ON"
            )
            op.open_extensions_tab = True

            # Open GitHub page
            update_row = update_box.row(align=True)
            op = update_row.operator(SimpleToolbox_OT_TakeMeToUpdate.bl_idname, text="Take me to GitHub!", icon="URL")
            op.open_extensions_tab = False

        # ====== Dev Tools ======
        if addon_prefs.dev_tools:
            dev_tools_header, dev_tools_panel = layout.panel_prop(addon_props, panelvis_dev_tools)
            if dev_tools_header:
                dev_tools_header.label(text="Dev Tools")

            if dev_tools_panel:

                # Show Addon Preferences
                row = dev_tools_panel.row()
                row.operator(SimpleToolbox_OT_ShowAddonPreferences.bl_idname, icon="PREFERENCES")

                # Row for Icon Viewer and Debug Mode
                row = dev_tools_panel.row()
                if is_dev_branch:
                    # Icon Viewer
                    row.operator(BUILTINS_OT_IconViewer.bl_idname)

                # Toggle Debug Mode
                row.operator(
                    SimpleToolbox_OT_ToggleDebugMode.bl_idname,
                    text="Debug",
                    icon="CONSOLE",
                    depress=addon_prefs.debug,
                )

                if is_dev_branch:
                    # Reload Scripts
                    row = dev_tools_panel.row()
                    row.operator("script.reload", text="Reload All Scripts", icon="PACKAGE")
                    reload_user_defined_box = dev_tools_panel.box()
                    row = reload_user_defined_box.row()
                    row.prop(addon_props, "reload_modules_prop")
                    row = reload_user_defined_box.row()
                    row.operator(SimpleToolbox_OT_ReloadNamedScripts.bl_idname, icon="TOOL_SETTINGS")

                if is_dev_branch and addon_prefs.experimental_features:
                    # Reload Images
                    row = dev_tools_panel.row()
                    row.operator("image.reload", icon="IMAGE_DATA")
                    row = dev_tools_panel.row()
                    row.operator(SimpleToolbox_OT_FixImageDataPaths.bl_idname, icon="IMAGE_DATA")

        # ====== Object Ops ======
        if cat_show_object_ops:
            object_ops_header, object_ops_panel = layout.panel_prop(addon_props, panelvis_object_ops)
            if object_ops_header:
                object_ops_header.label(text="Object Ops")

            if object_ops_panel:
                # >> Row
                object_ops_panel_row = object_ops_panel.row(align=True)
                row_split = object_ops_panel_row.split(align=True)
                # Clear Split Normals Data
                row_split.operator(SimpleToolbox_OT_ClearCustomSplitNormalsData.bl_idname)
                # Clear Objects Children
                row_split.operator(SimpleToolbox_OT_ClearChildrenRecurse.bl_idname)

                # >> Row
                object_ops_panel_row = object_ops_panel.row(align=True)
                row_split = object_ops_panel_row.split(align=True)
                # Select Empty Objects
                row_split.operator(SimpleToolbox_OT_SelectEmptyObjects.bl_idname)
                row_split.operator(SimpleToolbox_OT_SelectNonUniformScaleObjects.bl_idname)

                # >> Row
                object_ops_panel_row = object_ops_panel.row(align=True)
                row_split = object_ops_panel_row.split(align=True)
                # Remove unused Materials
                row_split.operator(SimpleToolbox_OT_RemoveUnusedMaterials.bl_idname)

                # >> Object Modifiers Panel
                object_modifiers_header, object_modifiers_ops_panel = object_ops_panel.panel_prop(
                    addon_props, panelvis_object_modifiers_ops
                )
                if object_modifiers_header:
                    object_modifiers_header.label(text="Modifiers")

                if object_modifiers_ops_panel:
                    # >> Row
                    object_modifiers_panel_row = object_modifiers_ops_panel.row(align=True)
                    object_modifiers_panel_row.prop(addon_prefs, "r0_double_subdiv_modifier_base_name", text="Name:")

                    # >> Row
                    object_modifiers_panel_row = object_modifiers_ops_panel.row(align=True)
                    object_modifiers_panel_row.operator(SimpleToolbox_OT_AddDoubleSubdivModifiers.bl_idname)

        # ====== Mesh Ops ======
        if cat_show_mesh_ops:
            mesh_ops_header, mesh_ops_panel = layout.panel_prop(addon_props, panelvis_mesh_ops)
            if mesh_ops_header:
                mesh_ops_header.label(text="Mesh Ops")

            if mesh_ops_panel:
                # >> Row
                mesh_ops_panel_row = mesh_ops_panel.row(align=True)
                row_split = mesh_ops_panel_row.split(align=True)
                # Remove Nth Edges Operator
                row_split.operator(SimpleToolbox_OT_DissolveNthEdge.bl_idname)

                # >> Row
                mesh_ops_panel_row = mesh_ops_panel.row(align=True)
                mesh_ops_panel_row.operator(SimpleToolbox_OT_ResetEdgeData.bl_idname)

                # >> Row
                mesh_ops_panel_row = mesh_ops_panel.row(align=True)
                row_split = mesh_ops_panel_row.split(align=True)
                # Restore rotation from Selection
                row_split.operator(SimpleToolbox_OT_RestoreRotationFromSelection.bl_idname)

                """
                # Clear Sharp Edges on Axis
                clear_sharp_edges_box = mesh_ops_panel.box()
                row = clear_sharp_edges_box.row(align=True)
                clear_sharp_edges_box.prop(
                    addon_props,
                    "show_clear_sharps_on_axis",
                    icon="TRIA_DOWN" if addon_props.show_clear_sharps_on_axis else "TRIA_RIGHT",
                    emboss=False,
                )
                if addon_props.show_clear_sharps_on_axis:
                    row = clear_sharp_edges_box.row(align=True)
                    row.prop(addon_prefs, "clear_sharp_axis_float_prop", text="Threshold")
                    row = clear_sharp_edges_box.row(align=True)
                    row.scale_x = 5
                    row.operator(SimpleToolbox_OT_ClearAxisSharpEdgesX.bl_idname, text="X")
                    row.operator(SimpleToolbox_OT_ClearAxisSharpEdgesY.bl_idname, text="Y")
                    row.operator(SimpleToolbox_OT_ClearAxisSharpEdgesZ.bl_idname, text="Z")
                """

        # ====== Find Modifiers ======
        if cat_show_find_modifiers_ops:
            find_modifiers_header, find_modifiers_panel = layout.panel_prop(addon_props, panelvis_find_modifier_ops)
            if find_modifiers_header:
                find_modifiers_header.label(text="Find Modifiers")

            if find_modifiers_panel:
                find_modifiers_panel_row = find_modifiers_panel.row()
                find_modifiers_panel_row.label(text="Name or Type (comma-separated):")
                find_modifiers_panel_row = find_modifiers_panel.row()
                find_modifiers_panel_row.prop(addon_props, "find_modifier_search_text", icon="SORTALPHA", text="")
                find_modifiers_panel_row.operator(
                    SimpleToolbox_OT_FindModifierSearch.bl_idname, icon="VIEWZOOM", text=""
                )

                find_modifiers_panel_row = find_modifiers_panel.row(align=True)
                op_collapse = find_modifiers_panel_row.operator(
                    SimpleToolbox_OT_FindModifiersCategoryVisCollapse.bl_idname, text="Collapse All", icon="TRIA_RIGHT"
                )
                op_collapse.collapse = True

                op_unfold = find_modifiers_panel_row.operator(
                    SimpleToolbox_OT_FindModifiersCategoryVisCollapse.bl_idname, text="Unfold All", icon="TRIA_DOWN"
                )
                op_unfold.collapse = False

                # Found objects UIList
                find_modifiers_panel_row = find_modifiers_panel.row()
                find_modifiers_panel_row.template_list(
                    "R0PROP_UL_FindModifierObjectsList",
                    "",
                    addon_find_modifier_props.objects_list,  # Collection owner
                    "found_objects",  # Collection property
                    addon_find_modifier_props.objects_list,  # Active item owner
                    "active_index",  # Active item property
                    rows=10,
                )

        # ====== Custom Properties UI List ======
        if cat_show_custom_properties_editor:
            draw_clear_custom_properties_ui(layout, context)
            draw_clear_objects_attributes_ui(layout, context)

        # ====== UV Ops ======
        if cat_show_uv_ops:
            uv_ops_header, uv_ops_panel = layout.panel_prop(addon_props, panelvis_uv_ops)
            if uv_ops_header:
                uv_ops_header.label(text="UV Ops")

            if uv_ops_panel:
                uv_ops_panel_row = uv_ops_panel.row()

                # UV Map Target Resolution
                row = uv_ops_panel_row.row()
                row.label(text="UV Map")

                dropdown_col = uv_ops_panel_row.column(align=True)
                dropdown_col.prop(addon_props, "uv_size_x", text="Width")
                dropdown_col.prop(addon_props, "uv_size_y", text="Height")

                # UV Island Thresholds
                uv_island_thresholds_header, uv_island_thresholds_panel = uv_ops_panel.panel(
                    "simpletoolbox_pt_uv_island_thresholds", default_closed=True
                )
                if uv_island_thresholds_header:
                    uv_island_thresholds_header.label(text="UV Island Area Thresholds")

                if uv_island_thresholds_panel:
                    values_row = uv_island_thresholds_panel.row()
                    split = values_row.split(factor=0.9)

                    col_sliders = split.column(align=True)
                    # col_sliders.prop(addon_props, "uvisland_sizecheck_arearelative", text="Factor:")
                    col_sliders.prop(addon_props, "uvisland_sizecheck_area_pixelcoverage", text="Pixel Area (px²):")
                    col_sliders.prop(addon_props, "uvisland_sizecheck_area_pixelpercentage", text="Pixel Area %:")

                    col_locks = split.column(align=True)
                    # col_locks.prop(addon_props, "use_uvisland_sizecheck_arearelative", text="")
                    col_locks.prop(addon_props, "use_uvisland_sizecheck_area_pixelcoverage", text="")
                    col_locks.prop(addon_props, "use_uvisland_sizecheck_area_pixelpercentage", text="")

                    row = uv_island_thresholds_panel.row()
                    row.operator(SimpleToolbox_OT_UVCheckIslandThresholds.bl_idname)

        # if addon_prefs.experimental_features:
        # experimental_features_box = layout.box()
        # experimental_features_box.prop(addon_props, "show_experimental_features", icon="TRIA_DOWN" addon_props.show_experimental_features else "TRIA_RIGHT", emboss=False)
        # if addon_props.show_experimental_features:
        # ...

        # ====== Online Repository ======
        draw_repo_layout(layout, context)


# -------------------------------------------------------------------
#   Register & Unregister
# -------------------------------------------------------------------

# fmt: off
classes = [
    r0Tools_PT_SimpleToolbox, 
]
# fmt: on


def register():
    for cls in classes:
        log.info(f"Register {cls.__name__}")
        bpy.utils.register_class(cls)

    # upd.trigger_update_check()
    upd.trigger_thread_update_check()


def unregister():
    for cls in classes:
        log.info(f"Unregister {cls.__name__}")
        bpy.utils.unregister_class(cls)


def unregister():
    for cls in classes:
        log.info(f"Unregister {cls.__name__}")
        bpy.utils.unregister_class(cls)
