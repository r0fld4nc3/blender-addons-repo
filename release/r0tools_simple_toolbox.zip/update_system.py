import logging

import bpy

from . import object_sets
from . import utils as u
from .operators import CustomTransformsOrientationsTracker
from .vertex_groups import vertex_groups_list_update

log = logging.getLogger(__name__)

_msgbus_owner = object()

_pending_updates = {
    "vertex_groups": False,
    "properties": False,
    "attributes": False,
    "objects": False,
    "cleanup": False,
}

_last_selection_hash = None
_last_object_count: int = 0

is_saving = False
is_updating = False  # Check if our depsgraph update is running

RESCHEDULE_DELAY: float = 1  # (X * 1000)ms

# ============================================================================
# Main Subscription Manager
# ============================================================================


def subscribe_to_all_changes():
    """
    Master subscription function - subscribes to all data changes needed.
    """
    log.debug("Establishing msgbus subscriptions...")

    # Clear any existing subscriptions
    bpy.msgbus.clear_by_owner(_msgbus_owner)

    # Subscribe to different data types
    _subscribe_to_selection_changes()

    log.debug("All msgbus subscriptions established")


def _subscribe_to_selection_changes():
    """Subscribe to active object and selection changes"""

    bpy.msgbus.subscribe_rna(
        key=(bpy.types.LayerObjects, "active"),
        owner=_msgbus_owner,
        args=(),
        notify=_on_selection_changed,
    )

    log.debug("Subscribed to active object changes")


def _subscribe_to_object_vertex_groups(obj):
    """Subscribe to vertex group changes on specific object"""
    try:
        bpy.msgbus.subscribe_rna(
            key=obj.path_resolve("vertex_groups", False),
            owner=_msgbus_owner,
            args=(obj,),
            notify=_on_vertex_groups_modified,
        )
    except Exception as e:
        log.warning(f"Unable to subscribe to vertex groups on {obj.name}: {e}")


# ============================================================================
# Msgbus Callbacks
# ============================================================================


def _on_selection_changed():
    """Selection changed callback"""
    log.debug("Selection changed")

    selected_objects = u.get_selected_objects()

    # Re-subscribe to vertex groups on new selected objects
    for obj in selected_objects:
        _subscribe_to_object_vertex_groups(obj)

    # Update selection hash
    global _last_selection_hash
    _last_selection_hash = _compute_selection_hash()

    # Schedule updates
    _pending_updates["vertex_groups"] = True
    _pending_updates["properties"] = True
    _pending_updates["attributes"] = True

    schedule_deferred_update()


def _on_vertex_groups_modified(obj):
    """Callback when vertex groups are added/removed/renamed on an object"""

    log.debug(f"Vertex groups modified on {obj.name}")

    if obj in u.get_selected_objects():
        _pending_updates["vertex_groups"] = True
        schedule_deferred_update()


# ============================================================================
# Depsgraph Fallback (Read-Only Detection Only)
# ============================================================================


@bpy.app.handlers.persistent
def on_depsgraph_update_post(scene, depsgraph):
    if u.is_saving() or u.is_updating():
        return

    global _last_selection_hash, _last_object_count

    # Run a very cheap object count C read gate for pre-checks
    current_count = len(scene.objects)
    if current_count != _last_object_count:
        _last_object_count = current_count
        _pending_updates["objects"] = True
        _pending_updates["cleanup"] = True
        schedule_deferred_update()

    # More expensive hash calculation but only iterates selection

    current_hash = _compute_selection_hash()

    if current_hash != _last_selection_hash:
        log.debug("Selection changed (depsgraph fallback)")
        _last_selection_hash = current_hash

        # Re-subscribe to vertex groups for the new selections
        for obj in u.get_selected_objects():
            _subscribe_to_object_vertex_groups(obj)

        _pending_updates["vertex_groups"] = True
        _pending_updates["properties"] = True
        _pending_updates["attributes"] = True
        schedule_deferred_update()

    """
    if depsgraph.id_type_updated(u.DEPSGRAPH_ID_TYPES.OBJECT):
        new_objects, was_deleted = u.get_object_changes(depsgraph)

        if new_objects:
            log.debug(f"Staging {len(new_objects)} new object(s) for processing.")
            object_sets.pending_known_objects.extend(new_objects)
            _pending_updates["objects"] = True

        if was_deleted:
            log.debug("Object deletion detected (depsgraph)")
            _pending_updates["cleanup"] = True

        if new_objects or was_deleted:
            schedule_deferred_update()
    """


def _compute_selection_hash():
    try:
        selected = tuple(sorted(obj.name for obj in u.get_selected_objects()))
        active_object = u.get_active_object()
        active_name = active_object.name if active_object else None
        return hash((selected, active_name))
    except Exception:
        return None


# ============================================================================
# Deferred Update Processing
# ============================================================================


def schedule_deferred_update():
    """Schedule update via timer - ONLY safe way to write ID properties."""
    if not bpy.app.timers.is_registered(_deferred_update):
        bpy.app.timers.register(_deferred_update, first_interval=0.0)


def _deferred_update():
    """
    Timer callback - run outside depsgraph evaluation.
    Returns a float to reschedule if context is still unsafe,
    or None to stop repeating once updates are processed.
    """
    scene = u.get_scene()

    # If context is not write-safe yet, reschedule rather than drop the update
    if scene is None or not u.is_writing_context_safe(scene):
        log.warning(f"Deferred update: context not write-safe, rescheduling in {RESCHEDULE_DELAY*1000}ms")
        return RESCHEDULE_DELAY

    _process_pending_updates()
    return None


def _process_pending_updates():
    """
    Process all pending updates in one batch.
    Only called from a write-safe context.
    """

    if u.is_saving():
        log.debug("Skipping updates: file is saving")
        return

    if u.is_updating():
        log.debug("Skipping updates: update already in progress")
        return

    # Redundant safety check
    scene = u.get_scene()
    if scene is None or not u.is_writing_context_safe(scene):
        log.warning("process_pending_updates: write context not safe, aborting")
        return

    if not any(_pending_updates.values()):
        log.debug("No pending updates to process.")
        return

    try:
        u.set_is_updating(True)

        # Vertex groups update
        if _pending_updates["vertex_groups"]:
            vertex_groups_list_update(scene=scene, force=True)
            _pending_updates["vertex_groups"] = False

        """
        # Objects update
        if _pending_updates["objects"]:
            u.handle_object_duplication_update(scene=scene)
            _pending_updates["objects"] = False

        # Cleanup
        if _pending_updates["cleanup"]:
            u.cleanup_object_set_invalid_references(scene=scene)
            _pending_updates["cleanup"] = False
        """

        # Objects or Cleanup
        if _pending_updates["objects"] or _pending_updates["cleanup"]:
            new_objects, deletions = u.get_object_changes_v2()

            if new_objects:
                object_sets.pending_known_objects.extend(new_objects)
                u.handle_object_duplication_update(scene=scene)

            if deletions:
                u.cleanup_object_set_invalid_references(scene=scene)

            _pending_updates["objects"] = False
            _pending_updates["cleanup"] = False

        # Properties update
        if _pending_updates["properties"]:
            u.property_list_update(scene=scene)
            _pending_updates["properties"] = False

        # Attributes update
        if _pending_updates["attributes"]:
            u.object_attributes_list_update(scene=scene)
            _pending_updates["attributes"] = False

        CustomTransformsOrientationsTracker.track_custom_orientations(scene)

    except Exception as e:
        log.error(f"Error processing updates: {e}")
        u.context_error_debug(error=e)
    finally:
        u.set_is_updating(False)


def _cancel_pending_updates():
    """
    Cancel any queued timer and clear all pending flags.
    Called externally by depsgraph save handlers to ensure
    the timer cannot fire during a restricted write context.
    """

    if bpy.app.timers.is_registered(_deferred_update):
        bpy.app.timers.unregister(_deferred_update)

    # v0.3.7: Remove reassignment, preferring mutate in place.
    for key in _pending_updates:
        _pending_updates[key] = False

    log.debug("Pending updates cancelled.")


def _resync_selection_hash():
    """
    Recompute and store the current selection hash after a save.
    Prevents the first post-save depsgraph tick from triggering
    an update due to a stale hash.
    """

    global _last_selection_hash
    _last_selection_hash = _compute_selection_hash()
    log.debug("Selection hash resynced after save.")


# ============================================================================
# Application Handlers
# ============================================================================


@bpy.app.handlers.persistent
def on_load_pre(_):
    log.debug("Load pre.")
    object_sets.clear_object_sets_cache()


@bpy.app.handlers.persistent
def on_load_post(_):
    log.debug("Load post - establishing subscriptions")
    global _last_selection_hash, _last_object_count
    scene = u.get_scene()
    _last_selection_hash = _compute_selection_hash()
    _last_object_count = len(scene.objects) if scene else 0  # Sync object count
    subscribe_to_all_changes()
    u.sync_known_objects()
    u.refresh_object_sets_colours(None)
    u.migrate_export_paths_on_load()


@bpy.app.handlers.persistent
def on_save_pre(_):
    """Set the save lock before a file is saved."""
    global is_saving
    is_saving = True

    # Cancel queued msgbus updates
    try:
        _cancel_pending_updates()
    except Exception as e:
        log.warning(f"Could not cancel pending updates on save pre: {e}")


@bpy.app.handlers.persistent
def on_save_post(_):
    """Clear the save lock after a file is saved."""
    global is_saving
    is_saving = False

    # Resync selection hash so the next depsgraph tick doesn't
    # trigger an update due to stale hash comparison
    try:
        _resync_selection_hash()
    except Exception as e:
        log.warning(f"Could not resync selection hash after save post: {e}")


@bpy.app.handlers.persistent
def on_undo_redo_post(_):
    log.debug("Undo/Redo post")

    subscribe_to_all_changes()
    u.sync_known_objects()
    object_sets.resync_object_sets_caches()

    _pending_updates["properties"] = True
    _pending_updates["attributes"] = True
    _pending_updates["objects"] = True
    _pending_updates["cleanup"] = True
    schedule_deferred_update()


_handlers: list[tuple] = [
    (bpy.app.handlers.load_pre, on_load_pre),
    (bpy.app.handlers.load_post, on_load_post),
    (bpy.app.handlers.save_pre, on_save_pre),
    (bpy.app.handlers.save_post, on_save_post),
    (bpy.app.handlers.undo_post, on_undo_redo_post),
    (bpy.app.handlers.redo_post, on_undo_redo_post),
    (bpy.app.handlers.depsgraph_update_post, on_depsgraph_update_post),
]


def register():
    for handler_list, handler_func in _handlers:
        if handler_func not in handler_list:
            handler_list.append(handler_func)
            log.debug(f"Registered handler: '{handler_func.__name__}'")

    log.info("Update system registered.")


def unregister():
    if bpy.app.timers.is_registered(_deferred_update):
        bpy.app.timers.unregister(_deferred_update)

    try:
        bpy.msgbus.clear_by_owner(_msgbus_owner)
    except Exception:
        pass

    for handler_list, handler_func in _handlers:
        if handler_func in handler_list:
            handler_list.remove(handler_func)
            log.debug(f"Unregistered handler: '{handler_func.__name__}'")

    log.info("Update system unregistered.")
