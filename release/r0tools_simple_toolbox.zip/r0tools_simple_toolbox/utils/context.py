import logging
from pathlib import Path

import bpy

from ..defines import INTERNAL_NAME, TOOLBOX_PROPS_NAME

log = logging.getLogger(__name__)

_last_object_count: int = 0
_known_object_pointers: set[int] = set()


def get_active_modal_operators(context: bpy.types.Context = None) -> list:
    """
    Return a `list` of active Modal Operators.

    When no Modal Operators are running, it will return an empty list
    """

    if context is None:
        context = bpy.context

    if not hasattr(context, "window"):
        return []

    if not hasattr(context.window, "modal_operators"):
        return []

    return context.window.modal_operators if context else []


def get_addon_props(scene=None):
    """Get the addon property group from current scene"""
    return get_scene(scene).r0fl_toolbox_props


def get_addon_object_sets_props(scene=None):
    """Get the addon property group from current scene"""
    return get_scene(scene).r0fl_object_sets_props


def get_object_props(obj: bpy.types.Object):
    """Get the Object-level Object properties from the given Object"""
    return obj.r0fl_toolbox_props


def get_addon_vertex_groups_props(scene=None):
    """Get the addon property group from current scene"""
    return get_scene(scene).r0fl_vertex_groups_props


def get_addon_edge_data_props(scene=None):
    """Get the addon property group from current scene"""
    return get_scene(scene).r0fl_toolbox_edge_data_props


def get_addon_experimental_props(scene=None):
    """Get the addon property group from current scene"""
    return get_scene(scene).r0fl_toolbox_experimental_props


def get_addon_find_modifier_props(scene=None):
    """Get the addon property group from current scene"""
    return get_scene(scene).r0fl_toolbox_find_modifier_props


def get_addon_export_props(scene=None):
    """Get the addon property group from current scene"""
    return get_scene(scene).r0fl_toolbox_export_props


def get_addon_prefs():
    """Get the addon preferences"""
    return bpy.context.preferences.addons[INTERNAL_NAME].preferences


def get_scene(scene=None) -> bpy.types.Scene:
    """Get the current scene"""
    return scene if scene else bpy.context.scene


def get_scene_name() -> str:
    """Get the name of the current scene"""
    return get_scene().name


def get_data_objects_len() -> int:
    return len(bpy.data.objects)


def sync_known_objects():
    """
    Resets the known object pointer baseline to the current scene state.
    Useful to call this on load, undo/redo, and after any intentional object mutation.
    """

    global _last_object_count, _known_object_pointers
    scene = get_scene()
    if not scene:
        return
    _known_object_pointers = {obj.as_pointer() for obj in scene.objects}
    _last_object_count = len(scene.objects)


def get_object_changes(depsgraph: bpy.types.Depsgraph) -> tuple[list[bpy.types.Object], bool]:
    """
    Identifies object additions and deletions from a depsgraph update.

    Attempt to use depsgraph.updates for efficiency.
    Fall back to pointer-set diff when depsgraph.updates does not expose new objects
    (i.e. outliner-based duplication).

    Syncs internal state before returning so the next call has a fresh baseline.

    Note: This triggers on every depsgraph update/tick, so it is important to have good guard clauses to keep initial checks cheap and minimal.

    Returns a tuple of:
        - list[Object]: Newly added objects (empty if none)
        - bool: True if a deletion was detected
    """
    global _last_object_count, _known_object_pointers

    scene = get_scene()
    if not scene:
        return [], False

    current_count = len(scene.objects)
    previous_count = _last_object_count
    _last_object_count = current_count

    log.debug(f"{current_count=}")
    log.debug(f"{previous_count=}")

    if current_count == previous_count:
        return [], False

    was_deleted = current_count < previous_count

    if was_deleted:
        # Unavoidable scene iteration
        _known_object_pointers = {obj.as_pointer() for obj in scene.objects}
        return [], True

    # Addition detected - try depsgraph.updates first
    updated_objects: list[bpy.types.Object] = [
        update.id
        for update in depsgraph.updates
        if isinstance(update.id, bpy.types.Object) and not update.id.is_evaluated
    ]

    # Filter only objects present in the scene
    scene_pointers = {obj.as_pointer(): obj for obj in scene.objects}
    new_from_depsgraph = [
        obj
        for obj in updated_objects
        if obj.as_pointer() not in _known_object_pointers and obj.as_pointer() in scene_pointers
    ]

    if new_from_depsgraph:
        _known_object_pointers = set(scene_pointers.keys())
        return new_from_depsgraph, False

    # Fallback: pointer diff (non-selection based duplications)
    new_pointers = scene_pointers.keys() - _known_object_pointers
    _known_object_pointers = set(scene_pointers.keys())

    new_objects = [scene_pointers[pointer] for pointer in new_pointers]
    return new_objects, False


def get_selection_mode(as_str=False) -> int | str:
    select_mode = bpy.context.tool_settings.mesh_select_mode

    mode_str = "VERT" if select_mode[0] else "EDGE" if select_mode[1] else "FACE" if select_mode[2] else "NONE"
    mode_int = 0 if select_mode[0] else 1 if select_mode[1] else 2 if select_mode[2] else -1

    if as_str:
        return mode_str

    return mode_int


def get_context_area() -> str | None:
    """Get the current area type or None if unavailable"""
    if not bpy.context.area:
        return None
    return bpy.context.area.ui_type


def get_addon_fs_path() -> Path:
    """Get the filesystem path to the addon directory from THIS file"""
    return Path(__file__).resolve().parent.parent


def get_depsgraph():
    """Get the current dependency graph"""
    return bpy.context.evaluated_depsgraph_get()


def get_depsgraph_is_updated_geometry() -> bool:
    """Check if geometry was updated in the depsgraph"""
    d = get_depsgraph()
    for update in d.updates:
        return update.is_updated_geometry
    return False


def get_depsgraph_is_updated_shading() -> bool:
    """Check if shading was updated in the depsgraph"""
    d = get_depsgraph()
    for update in d.updates:
        return update.is_updated_shading
    return False


def get_depsgraph_is_updated_transform() -> bool:
    """Check if transforms were updated in the depsgraph"""
    d = get_depsgraph()
    for update in d.updates:
        return update.is_updated_transform
    return False


def is_viewport_local() -> bool:
    area = next(a for a in bpy.context.screen.areas if a.type == "VIEW_3D")
    space = area.spaces.active
    if space.local_view:
        return True

    return False


def toggle_viewport_local_mode():
    area = next(a for a in bpy.context.screen.areas if a.type == "VIEW_3D")
    with bpy.context.temp_override(area=area):
        bpy.ops.view3d.localview(frame_selected=False)


def get_uvmap_size_x():
    """Get selected UV Map Size in X"""
    addon_props = get_addon_props()
    return int(addon_props.uv_size_x)


def get_uvmap_size_y():
    """Get selected UV Map Size in Y"""
    addon_props = get_addon_props()
    return int(addon_props.uv_size_y)


def is_saving() -> bool:
    from .. import depsgraph

    return depsgraph.is_saving


def is_updating() -> bool:
    from .. import depsgraph

    return depsgraph.is_updating


def set_is_updating(state: bool):
    from .. import depsgraph

    depsgraph.is_updating = state


def file_version_greater_than_blender_version(compare_major: bool = True) -> bool:
    from ..utils import get_blender_version, get_file_version

    file_version = get_file_version()
    blender_version = get_blender_version()

    if compare_major:
        file_version = file_version[0]
        blender_version = blender_version[0]

    # File version greater than Blender version
    if file_version > blender_version:
        log.info(f"File version {file_version} > Blender version {blender_version}.")
        return True
    else:
        log.info(f"File version {file_version} <= Blender version {blender_version}.")

    return False


def is_writing_context_safe(scene) -> bool:
    """
    Potential fix for "AttributeError: Writing to ID classes in this context is now allowed: Scene, Scene datablock
    """

    if is_saving():
        log.info(f"Unsafe write context while file is being saved.")
        return False

    scene = get_scene(scene)

    if not hasattr(scene, TOOLBOX_PROPS_NAME):
        log.info(f"Scene does not have proper attribute(s) '{TOOLBOX_PROPS_NAME}'. Skipping.")
        return False

    # Check if rendering or baking is active
    if scene.render.use_lock_interface:
        log.info(f"[MONITOR] Interface is locked (rendering/baking). Skipping.")
        return False

    # Additional check for bake operator
    if hasattr(bpy.context, "active_operator") and bpy.context.active_operator:
        op_idname = bpy.context.active_operator.bl_idname
        if "bake" in op_idname.lower():
            log.info(f"[MONITOR] Bake operator active: {op_idname}. Skipping.")
            return False

    # Check for active jobs
    jobs = ("RENDER", "COMPOSITE", "OBJECT_BAKE")
    jobs_active = [bpy.app.is_job_running(job) for job in jobs]
    if any(jobs_active):
        log.info(f"[MONITOR] Active job(s) detected. Skipping.")
        return False

    # A generalist broader check if all else fails
    # If the context is restricted for ANY reason, wm.save_as_mainfile
    # will not poll. This catches mid-operator evaluation, modal operator locks
    # and other restricted states not covered above.
    try:
        if not bpy.ops.wm.save_as_mainfile.poll():
            log.info("[MONITOR] Context restricted (poll failed). Skipping")
            return False
    except Exception as e:
        log.error(e)
        return False

    return True


def save_preferences():
    """Safely save user preferences without causing recursion"""
    try:
        if not hasattr(save_preferences, "is_saving"):
            save_preferences.is_saving = False

        if not save_preferences.is_saving:
            save_preferences.is_saving = True
            bpy.context.preferences.use_preferences_save = True
            bpy.ops.wm.save_userpref()
            save_preferences.is_saving = False
    except Exception as e:
        log.error(f"Error saving preferences: {e}")
        save_preferences.is_saving = False
