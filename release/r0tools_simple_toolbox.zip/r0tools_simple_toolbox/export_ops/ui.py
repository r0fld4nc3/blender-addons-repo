import logging

import bpy

from .. import utils as u
from ..defines import ADDON_CATEGORY, ADDON_NAME_BARE, IDNAME_EXTRA
from .operators import *

log = logging.getLogger(__name__)


class r0Tools_PT_SimpleToolboxQuickExportOps(bpy.types.Panel):
    bl_idname = "OBJECT_PT_simple_toolbox_quick_export_ops"
    bl_label = f"Quick Export - {ADDON_NAME_BARE}{IDNAME_EXTRA}"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Item"
    bl_options = {"DEFAULT_CLOSED", "INSTANCED"}
    bl_order = 4

    @classmethod
    def poll(cls, context):
        addon_prefs = u.get_addon_prefs()
        addon_props = u.get_addon_props()
        experimental_enabled = addon_prefs.experimental_features
        show_panel = addon_props.cat_show_quick_export_panel

        return experimental_enabled and show_panel

    def draw(self, context):
        layout = self.layout

        layout.label(text="Quick Export (FBX)")

        u.draw_quick_export_sets_uilist(layout, context)


classes = []

# fmt: off
panel_attributions = {
    r0Tools_PT_SimpleToolboxQuickExportOps: {
        "categories": [ADDON_CATEGORY, "Item"]
    }
}
# fmt : on


def register():
    classes.clear() # Prevent duplicates
    
    for panel_class, values in panel_attributions.items():
        categories = values.get("categories")
        for cat in categories:
            variant = u.create_panel_variant(panel_class, category=cat)
            classes.append(variant)

    for cls in classes:
        log.debug(f"Register {cls.__name__}")
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        log.debug(f"Unregister {cls.__name__}")
        bpy.utils.unregister_class(cls)

    classes.clear()
